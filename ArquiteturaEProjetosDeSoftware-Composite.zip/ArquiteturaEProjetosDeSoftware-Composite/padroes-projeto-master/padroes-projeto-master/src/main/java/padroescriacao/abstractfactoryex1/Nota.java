package padroescriacao.abstractfactoryex1;

public interface Nota {
    String emitir();
}
