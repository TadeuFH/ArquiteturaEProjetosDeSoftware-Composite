package padroescriacao.abstractfactoryex1;

public class DisciplinaEnsinoFundamental implements Disciplina{

    public String emitir() {
        return "Disciplina Ensino Fundamental";
    }
}
