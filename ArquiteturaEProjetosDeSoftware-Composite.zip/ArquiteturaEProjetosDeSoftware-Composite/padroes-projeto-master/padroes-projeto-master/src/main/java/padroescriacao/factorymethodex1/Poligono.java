package padroescriacao.factorymethodex1;

public interface Poligono {
    String getDescripition();
}
