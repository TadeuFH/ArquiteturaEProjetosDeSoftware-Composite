package padroescriacao.factorymethodex1;

public class Quadrado implements Poligono{
    public String getDescripition() {
        return "Quadrado";
    }
}
