package padroescriacao.abstractfactory;

public class DiplomaGraduacao implements Diploma {

    public String emitir() {
        return "Diploma de Graduação";
    }
}
