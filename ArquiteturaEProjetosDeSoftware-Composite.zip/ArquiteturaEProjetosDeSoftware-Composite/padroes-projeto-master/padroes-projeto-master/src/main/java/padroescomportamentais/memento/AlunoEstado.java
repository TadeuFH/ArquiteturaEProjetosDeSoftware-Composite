package padroescomportamentais.memento;

import padroescomportamentais.state.Aluno;

public interface AlunoEstado {
    
    String getNomeEstado();
    
}
