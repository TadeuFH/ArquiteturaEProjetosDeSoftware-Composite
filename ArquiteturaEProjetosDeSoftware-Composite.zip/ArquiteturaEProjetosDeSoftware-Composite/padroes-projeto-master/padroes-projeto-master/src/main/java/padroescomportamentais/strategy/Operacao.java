package padroescomportamentais.strategy;

public interface Operacao {

    float calcular(float valor1, float valor2);
}
