package padroesestruturais.bridge;

public class Doutorado implements Escolaridade {

    public float percentualAumento() {
        return 0.3f;
    }
}
