package padroesestruturais.decoratorex1;

public class CheeseDecorator extends HamburgerDecorator {
    public CheeseDecorator(Hamburger hamburger) {
        super(hamburger);
    }

    public String getDescription() {
        return hamburger.getDescription() + ", queijo";
    }

    public double getCost() {
        return hamburger.getCost() + 1.5;
    }
}