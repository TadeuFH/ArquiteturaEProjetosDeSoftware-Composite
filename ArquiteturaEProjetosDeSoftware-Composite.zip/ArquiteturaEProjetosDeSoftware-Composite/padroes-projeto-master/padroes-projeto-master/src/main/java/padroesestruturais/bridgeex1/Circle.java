package padroesestruturais.bridgeex1;

public class Circle implements Shape {
    private Color color;

    public Circle(Color color) {
        this.color = color;
    }

    @Override
    public String draw() {
        return "Drawing a circle in " + color.getColor();
    }
}