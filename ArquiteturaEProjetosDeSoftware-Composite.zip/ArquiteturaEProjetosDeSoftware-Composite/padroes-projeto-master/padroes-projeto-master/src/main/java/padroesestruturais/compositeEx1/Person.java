package padroesestruturais.compositeEx1;

import java.util.ArrayList;
import java.util.List;

public abstract class Person {
    private String name;
    private int age;
    private List<Person> children;
    private List<Person> parents;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        this.children = new ArrayList<>();
        this.parents = new ArrayList<>();
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public void addChild(Person child) {
        this.children.add(child);
    }

    public void removeChild(Person child) {
        this.children.remove(child);
    }

    public List<Person> getChildren() {
        return this.children;
    }

    public void addParent(Person parent) {
        this.parents.add(parent);
    }

    public List<Person> getParents() {
        return this.parents;
    }

    public void removeParent(Person parent) {
        this.parents.remove(parent);
    }
}
