package padroesestruturais.compositeEx1;

public class Individual extends Person {
    public Individual(String name, int age) {
        super(name, age);
    }
}
