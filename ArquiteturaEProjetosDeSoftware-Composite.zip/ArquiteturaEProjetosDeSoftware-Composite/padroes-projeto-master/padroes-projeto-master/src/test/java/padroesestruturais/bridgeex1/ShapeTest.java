package padroesestruturais.bridgeex1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ShapeTest {
    @Test
    public void testShape() {
        Shape redCircle = new Circle(new Red());
        Shape blueRectangle = new Rectangle(new Blue());
        Shape greenCircle = new Circle(new Green());

        assertEquals("Drawing a circle in red", redCircle.draw());
        assertEquals("Drawing a rectangle in blue", blueRectangle.draw());
        assertEquals("Drawing a circle in green", greenCircle.draw());
    }
}

